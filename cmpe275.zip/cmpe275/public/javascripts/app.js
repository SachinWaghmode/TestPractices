
var routerApp = angular.module('routerApp', ['ui.router', 'ngStorage']);
routerApp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/');

    $stateProvider
    //States start here-----------------------------------------------------------------


        //-------------------------------------------------------------------------------       
        .state('app',{
            url: '/',
            views: {
                'header@':{
                    templateUrl: '/html/header.html'
                },
                'content@':{
                    templateUrl: '/html/login.html',
                    controller: 'loginController'
                }
            }
        })

        .state('app.register', {
            url: 'register',
            views: {
                'header':{
                    templateUrl: '/html/header.html'
                },
                'content':{
                    templateUrl: '/html/register.html',
                    controller: 'registerController'
                }

            }
        })

        .state('app.homepage',{
            url: 'homepage',
            views: {
                'header@':{
                    templateUrl: '/html/header.html'
                },
                'content@':{
                    templateUrl: '/html/homepage.html',
                    controller: 'homeController'
                }
            }
        })
        //-------------------------------------------------------------------------------
        .state('app.search',{
            url: 'home',
            views: {
                'header@':{
                    templateUrl: '/html/header.html'
                },
                'content@':{
                    templateUrl: '/html/SearchTrain.html',
                    controller: 'searchController'
                }
            }
        })

        .state('app.bookticket',{
            url: 'booking',
            views: {
                'header@':{
                    templateUrl: '/html/header.html'
                },
                'content@':{
                    templateUrl: '/html/booking.html',
                    controller: 'bookingController'
                }
            }
        })

        .state('app.showticket',{
            url: 'ticket',
            views: {
                'header@':{
                    templateUrl: '/html/header.html'
                },
                'content@':{
                    templateUrl: '/html/ticket.html',
                    controller: 'ticketController'
                }
            }
        })

});

//States end here----------------------------------------------------------------------------------------------
///Controllers Start here--------------------------------------------------------------------------------------

var gemail = "";
routerApp.controller('loginController',['$scope','$http','$state','$window',function($scope,$http,$state,$window){
    $scope.login=function(){
            gemail = $scope.email
        console.log("email in login", gemail)
            $http({
                method:'post',
                url:'http://localhost:8080/login',
                headers: {"Content-Type":"application/x-www-form-urlencoded"},
                transformRequest: function(obj) {
                    var str = [];
                    for(var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data:{
                    "email":$scope.email,
                    "password":$scope.password
                }

            }).then(function(data){
                console.log(data);
                $state.transitionTo("app.homepage");
                if(data.status==200){
                    console.log(data.token);
                    //$state.transitionTo("app.homepage");
                }
                else{


                }
            },
                function errorCallback(response) {
                    console.log(response);
                    //$window.location.reload();
                });




    }
    $scope.switchToRegister=function(){
        $state.transitionTo("app.register");
        console.log("inside state transition to log-reg");
    }
}])



routerApp.controller('registerController',['$scope','$http','$state','$window',function($scope,$http,$state,$window){
    $scope.register=function(){

        console.log("inside register function");

            $http({
                method:'post',
                url:'http://localhost:8080/register',
                headers: {"Content-Type":"application/x-www-form-urlencoded"},
                transformRequest: function(obj) {
                    var str = [];
                    for(var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data:{

                    email:$scope.email,

                    password:$scope.password



                }

            }).then(function(data){
                console.log(data);
                console.log("inside success");
                console.log($scope.email);
                $state.transitionTo("app.home");
                if(data.status==200){
                    console.log(data.token);

                }
                else{


                }
            })


    }
    $scope.fromlogintoregister=function(){
        $state.transitionTo("app");
    }
    console.log("end of register");
}])

routerApp.controller('homeController',['$scope','$http','$state','$window',function($scope,$http,$state,$window){

    $scope.searchpage=function(){
        $state.transitionTo("app.search");
    }

    $scope.cancelTicket=function(){
        $state.transitionTo("app.book");
    }
    $scope.cancelTrain=function(){
        $state.transitionTo("app.book");
    }
}])

routerApp.controller('searchController',['$scope','$http','$state','$window',function($scope,$http,$state,$window){
    var resp="";
    $scope.search=function() {
        console.log("email in search", gemail)
        console.log("inside search function");
        console.log($scope.departuredate);
        console.log($scope.departuretime);
        console.log($scope.fromstation);
        console.log($scope.tostation);
        console.log($scope.noofconnections);
        console.log($scope.nooftickets);
        console.log($scope.tickettype);
        console.log($scope.traintype);
        console.log($scope.returntripdate);
        console.log($scope.returntriptime);

        $http({
            method: 'post',
            url: 'http://localhost:8080/train/search',
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            transformRequest: function (obj) {
                var str = [];
                for (var p in obj)
                    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                return str.join("&");
            },
            data: {
                email : gemail,
                departuredate: $scope.departuredate,
                departuretime: $scope.departuretime,
                fromstation: $scope.fromstation,
                tostation: $scope.tostation,
                noofconnections: $scope.noofconnections,
                nooftickets: $scope.nooftickets,
                tickettype: 'O',
                traintype: 'R',
                returntripdate: '2017-12-20',
                returntriptime: '0700'

            }

        }).then(function (response) {
            console.log(response);
            console.log(response.data);
            console.log(response.data[1]);
            console.log(response.data[1][0].trainNumber);
            console.log("inside success");
           $scope.value = response.data[2][0];
           console.log($scope.value.trainNumber);
          //  $state.transitionTo("app.bookticket");
            console.log("after transition");
            console.log($scope.value.trainNumber);

             resp= JSON.stringify(response);
            console.log("jsonresp"+resp);


        })




    }


    $scope.book=function(){
        //console.log("test"+x);
        console.log("Inside book train still persist : "+resp);
        console.log("Full scope id as " , $scope);
        console.log("Sending rider id as " ,$scope.value.trainNumber);
        $http({
            method:'POST',
            url:'http://localhost:8080/train/purchase',
            headers: {"Content-Type":"application/x-www-form-urlencoded"},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj)
                    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                return str.join("&");
            },
            data:{
                email: gemail,
                jstring: resp

            }

        }).then(function(data){
            console.log(data);
            $state.transitionTo("app.showticket");
            if(data.status==200){
                console.log(data.token);
                //$state.transitionTo("app.rideStatus");
            }
            else{


            }
        })

    }
}])

/*
routerApp.controller('bookingController',['$scope','$http','$state','$window',function($scope,$http,$state,$window){
//routerApp.controller('getRidesController',['$scope','$http','$state','$window',function($scope,$http,$state,$window){
    //get request for requested rides
    $scope.book=function() {
        console.log("inside booking");
        console.log($scope.value.trainNumber);
        $http({
            method: 'post',
            url: 'http://localhost:8080/train/search1',
            headers: {"Content-Type": "application/x-www-form-urlencoded"},

            data: {
                J
            }

        }).success(function (data) {
            console.log(data);
            console.log(data[0]);
            console.log(data[0].reason);
            $scope.data = data;
            if (data.statusCode == 200) {


                $scope.data = data;

            }

            else {


            }
        }).error(function (error) {
            console.log(error);
        })

        /*
        //post request for selected train -booking
        $scope.book=function(){
            //console.log("test"+x);
            console.log("Full scope id as " , $scope)
            console.log("Sending rider id as " + $scope);
            $http({
                method:'POST',
                url:'http://localhost:8080/train/purchase',
                headers: {"Content-Type":"application/x-www-form-urlencoded"},
                transformRequest: function(obj) {
                    var str = [];
                    for(var p in obj)
                        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
                    return str.join("&");
                },
                data:{
                    rideId:$scope.rideid,
                    rideStatus:'A'

                }

            }).then(function(data){
                console.log(data);
                if(data.status==200){
                    console.log(data.token);
                    $state.transitionTo("app.showticket");
                }
                else{


                }
            })

        }


        //Redirecting to driver history page
    }
}])
*/
//routerApp.controller('ticketController',['$scope','$http','$state','$window',function($scope,$http,$state,$window){
routerApp.controller('ticketController',['$scope','$http','$state','$window',function($scope,$http,$state,$window){
  $scope.ticket=function() {
      console.log("Inside get ticket",gemail);
      $http({
          method: 'POST',
          url: 'http://localhost:8080/train/showticket',
          headers: {"Content-Type": "application/x-www-form-urlencoded"},

          data: {
              email: gemail
          }

      }).success(function (data) {
          console.log("*****: ", data);
          console.log(data[0]);
          $scope.value = data;
          // console.log("After : ",$scope.value.id);

      }).error(function (error) {

      })

      //-----------Go Back
  }
}])

//Controllers end here---------------------------------------------------------------------------------------------------
