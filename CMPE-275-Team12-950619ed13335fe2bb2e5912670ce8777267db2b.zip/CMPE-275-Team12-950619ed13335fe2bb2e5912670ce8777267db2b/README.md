# CMPE-275-Team12
Java Spring JPA 


#California Ultra-Speed Rail (CUSR) train ticket booking system

##Team-12:
Contributors:
   Name                     Email-Id                             SJSU-Id
1. Sachin Dadaso Waghmode   sachindadaso.waghmode@sjsu.edu       011424192
2. Shraddha Yeole           shraddha.yeole@sjsu.edu              011424205
3. Suchita Mudholakr        suchitakamalakar.mudholkar@sjsu.edu  011812736
